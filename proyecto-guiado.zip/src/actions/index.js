export const SET_CITY = 'SET_CITY'

// setCity es un actionCreator
export const setCity = (value) => ({type: SET_CITY, value});